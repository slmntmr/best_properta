package com.team02.best_properta.payload.mappers;

public class dummy {
}
