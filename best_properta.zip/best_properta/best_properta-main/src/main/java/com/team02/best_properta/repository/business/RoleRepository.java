package com.team02.best_properta.repository.business;

public interface RoleRepository {
}
