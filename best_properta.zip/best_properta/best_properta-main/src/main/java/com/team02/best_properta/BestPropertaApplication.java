package com.team02.best_properta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BestPropertaApplication  {

	public static void main(String[] args) {
		SpringApplication.run(BestPropertaApplication.class, args);
	}

}
