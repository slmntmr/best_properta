package com.team02.best_properta.payload.request.abstracts;

public class dummy {
}
