package com.team02.best_properta.security.service;

public class dummy {
}