package com.team02.best_properta.payload.response.business;

public class dummy {
}
