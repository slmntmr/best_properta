package com.team02.best_properta.payload.response.authentication;

public class dummy {
}
