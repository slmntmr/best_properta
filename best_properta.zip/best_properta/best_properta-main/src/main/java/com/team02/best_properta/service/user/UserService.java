package com.team02.best_properta.service.user;

public class UserService {
}
