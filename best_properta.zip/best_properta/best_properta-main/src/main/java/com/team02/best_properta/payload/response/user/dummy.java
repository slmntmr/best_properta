package com.team02.best_properta.payload.response.user;

public class dummy {
}
