package com.team02.best_properta.payload.request.business;

public class dummy {
}
