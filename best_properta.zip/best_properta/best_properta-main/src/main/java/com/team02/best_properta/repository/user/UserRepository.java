package com.team02.best_properta.repository.user;

public interface UserRepository {
}
