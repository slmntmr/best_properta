package com.team02.best_properta.controller.user;

public class UserController {
}
