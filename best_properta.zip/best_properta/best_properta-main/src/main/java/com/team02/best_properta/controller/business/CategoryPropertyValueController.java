package com.team02.best_properta.controller.business;

public class CategoryPropertyValueController {
}
