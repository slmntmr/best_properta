package com.team02.best_properta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BestPropertaApplicationTests {

	@Test
	void contextLoads() {
	}

}
